#pragma once

void Intro();
char ShopMenu();
