#pragma once

char ParlourMenu();