#pragma once

char ShopQuotes();
void QuoteShopMenu(double currentPlayerIQ, int *repertoire);
double GetCheapestQuote();
void PrintQuoteAuthor(int selectedAuthor);
void QuoteParlourMenu(int* playerRepertoire);
double PrintQuote(int desiredQuote, int* repertoire);