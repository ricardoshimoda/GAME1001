#pragma once

int const NUM_QUOTES = 9;
double const START_IQ = 90;
bool const DOOMSDAY = false;


